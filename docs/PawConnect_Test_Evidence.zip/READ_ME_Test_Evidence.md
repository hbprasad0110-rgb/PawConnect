# PawConnect Test Execution Evidence

## Observed results
| Evidence | Check | Result |
|---|---|---|
| E01 | Node test runner: four animal-state tests and one Supertest API health test | 5 passed, 0 failed |
| E02 | Frontend TypeScript check | Passed, exit code 0 |
| E03 | Backend TypeScript build and frontend Vite production build | Passed, exit code 0 |

The five automated test cases are: adoption happy path; rejection handling with and without other active applications; withdrawal handling; rejection of an invalid transition; and GET /api/health. The health endpoint test is explicitly designed not to require a database connection. Four test cases contain several assertions, so five test cases should not be described as five individual assertions.

The production build reports a JavaScript chunk larger than 500 kB after minification. This is a build warning, not a failing test. See E03 for exact bundle sizes.



